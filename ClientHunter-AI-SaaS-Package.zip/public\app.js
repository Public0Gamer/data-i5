let allLeads = [];
let currentFilter = 'all';
let currentPage = 1;
let currentSearchParams = null;

// Comprehensive Global Countries & Regions Database
const COUNTRY_STATES = {
  'United States': ['Florida', 'California', 'New York', 'Texas', 'Illinois', 'Georgia', 'Washington', 'Ohio', 'Pennsylvania', 'North Carolina', 'Arizona', 'Colorado', 'Massachusetts', 'Nevada'],
  'United Kingdom': ['Greater London', 'Greater Manchester', 'West Midlands', 'West Yorkshire', 'Scotland', 'Wales', 'Merseyside', 'South Yorkshire'],
  'United Arab Emirates': ['Dubai', 'Abu Dhabi', 'Sharjah', 'Ajman', 'Ras Al Khaimah', 'Fujairah'],
  'India': ['Maharashtra', 'Delhi NCR', 'Karnataka', 'Tamil Nadu', 'Gujarat', 'Rajasthan', 'Telangana', 'Uttar Pradesh', 'West Bengal', 'Punjab', 'Kerala'],
  'Canada': ['Ontario', 'British Columbia', 'Quebec', 'Alberta', 'Manitoba', 'Nova Scotia'],
  'Australia': ['New South Wales', 'Victoria', 'Queensland', 'Western Australia', 'South Australia'],
  'Germany': ['Berlin', 'Bavaria', 'Hamburg', 'Hesse', 'North Rhine-Westphalia', 'Baden-Württemberg'],
  'France': ['Île-de-France', 'Provence-Alpes-Côte d\'Azur', 'Auvergne-Rhône-Alpes', 'Nouvelle-Aquitaine'],
  'Italy': ['Lombardy (Milan)', 'Lazio (Rome)', 'Campania (Naples)', 'Veneto (Venice)', 'Tuscany (Florence)'],
  'Spain': ['Madrid', 'Catalonia (Barcelona)', 'Andalusia', 'Valencia', 'Basque Country'],
  'Netherlands': ['North Holland (Amsterdam)', 'South Holland (Rotterdam)', 'Utrecht', 'North Brabant'],
  'Switzerland': ['Zurich', 'Geneva', 'Basel', 'Vaud', 'Bern'],
  'Sweden': ['Stockholm', 'Västra Götaland (Gothenburg)', 'Skåne (Malmö)'],
  'Saudi Arabia': ['Riyadh', 'Makkah (Jeddah)', 'Eastern Province', 'Madinah'],
  'Singapore': ['Central Region', 'East Region', 'West Region', 'North Region'],
  'Japan': ['Tokyo', 'Osaka', 'Kyoto', 'Kanagawa', 'Aichi', 'Fukuoka'],
  'South Korea': ['Seoul', 'Busan', 'Incheon', 'Gyeonggi'],
  'Brazil': ['São Paulo', 'Rio de Janeiro', 'Minas Gerais', 'Bahia', 'Paraná'],
  'Mexico': ['Mexico City', 'Jalisco (Guadalajara)', 'Nuevo León (Monterrey)', 'Puebla'],
  'South Africa': ['Gauteng (Johannesburg)', 'Western Cape (Cape Town)', 'KwaZulu-Natal (Durban)'],
  'New Zealand': ['Auckland', 'Wellington', 'Canterbury (Christchurch)'],
  'Ireland': ['Dublin', 'Cork', 'Galway', 'Limerick'],
  'Poland': ['Masovian (Warsaw)', 'Lesser Poland (Krakow)', 'Lower Silesia (Wroclaw)'],
  'Turkey': ['Istanbul', 'Ankara', 'Izmir', 'Antalya'],
  'Indonesia': ['Jakarta', 'Bali', 'West Java (Bandung)', 'East Java (Surabaya)'],
  'Malaysia': ['Kuala Lumpur', 'Selangor', 'Penang', 'Johor'],
  'Thailand': ['Bangkok', 'Chiang Mai', 'Phuket', 'Chonburi'],
  'Qatar': ['Doha', 'Al Rayyan', 'Al Wakrah'],
  'Global / Other': ['All Regions / Nationwide']
};

document.addEventListener('DOMContentLoaded', () => {
  // Check License
  const savedKey = localStorage.getItem('hunter_license_v2');
  const overlay = document.getElementById('license-overlay');
  if (savedKey && overlay) overlay.classList.add('hidden');

  // Country/State Cascading
  const countrySelect = document.getElementById('select-country');
  const stateSelect = document.getElementById('select-state');

  function updateStates() {
    const selectedCountry = countrySelect.value;
    const states = COUNTRY_STATES[selectedCountry] || ['All Regions'];
    stateSelect.innerHTML = '';
    states.forEach(st => {
      const opt = document.createElement('option');
      opt.value = st;
      opt.textContent = st;
      stateSelect.appendChild(opt);
    });
  }

  if (countrySelect && stateSelect) {
    countrySelect.addEventListener('change', updateStates);
    updateStates();
  }

  // Niche chips
  document.querySelectorAll('.niche-preset-chip').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      document.getElementById('input-niche').value = btn.getAttribute('data-niche');
    });
  });

  // Filter Pills
  document.querySelectorAll('.filter-pill').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-pill').forEach(b => {
        b.classList.remove('bg-blue-50', 'text-blue-700', 'border-blue-300');
        b.classList.add('bg-white', 'text-slate-700', 'border-slate-200');
      });
      btn.classList.remove('bg-white', 'text-slate-700', 'border-slate-200');
      btn.classList.add('bg-blue-50', 'text-blue-700', 'border-blue-300');
      currentFilter = btn.getAttribute('data-filter');
      renderCards();
    });
  });
});

// Strict License Unlock
const btnUnlock = document.getElementById('btn-unlock');
if (btnUnlock) {
  btnUnlock.addEventListener('click', async () => {
    const key = document.getElementById('license-input').value.trim();
    const errorMsg = document.getElementById('license-error-msg');
    errorMsg.classList.add('hidden');

    if (!key) {
      errorMsg.textContent = 'Please enter your purchased license key.';
      errorMsg.classList.remove('hidden');
      return;
    }

    try {
      btnUnlock.textContent = 'Verifying Authenticity...';
      const res = await fetch('/api/auth/verify-license', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ licenseKey: key })
      });
      const data = await res.json();

      if (data.valid) {
        localStorage.setItem('hunter_license_v2', key);
        document.getElementById('license-overlay').classList.add('hidden');
      } else {
        errorMsg.textContent = data.message || 'Access Denied: Invalid License Key.';
        errorMsg.classList.remove('hidden');
      }
    } catch (err) {
      errorMsg.textContent = 'Network error checking license.';
      errorMsg.classList.remove('hidden');
    } finally {
      btnUnlock.textContent = 'Verify License & Unlock Engine →';
    }
  });
}

function logLine(msg, icon = '📍') {
  const container = document.getElementById('telemetry-log');
  if (!container) return;
  const time = new Date().toLocaleTimeString();
  const div = document.createElement('div');
  div.className = 'flex items-center space-x-2 py-0.5';
  div.innerHTML = `<span class="text-blue-600 font-bold">[${time}]</span> <span>${icon}</span> <span>${msg}</span>`;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

// Initial Search Handler
const huntForm = document.getElementById('hunt-form-v2');
if (huntForm) {
  huntForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const niche = document.getElementById('input-niche').value.trim();
    const country = document.getElementById('select-country').value;
    const state = document.getElementById('select-state').value;
    const city = document.getElementById('input-city').value.trim();

    if (!niche || !city) return;

    currentPage = 1;
    currentSearchParams = { niche, country, state, city };
    allLeads = [];

    const btnHunt = document.getElementById('btn-hunt');
    const btnLabel = document.getElementById('btn-hunt-label');
    const spinner = document.getElementById('hunt-spinner');
    const scannerSection = document.getElementById('scanner-section');
    const emptyState = document.getElementById('empty-state');
    const statusText = document.getElementById('scanner-status');
    const speedBadge = document.getElementById('scanner-speed-badge');
    const logBox = document.getElementById('telemetry-log');
    const loadMoreContainer = document.getElementById('load-more-container');
    const noMoreText = document.getElementById('no-more-text');
    const btnLoadMore = document.getElementById('btn-load-more');

    btnHunt.disabled = true;
    btnLabel.textContent = 'Scanning Maps in Real-Time...';
    spinner.classList.remove('hidden');
    scannerSection.classList.remove('hidden');
    if (emptyState) emptyState.classList.add('hidden');
    logBox.innerHTML = '';
    speedBadge.textContent = 'Scanning...';
    if (loadMoreContainer) loadMoreContainer.classList.add('hidden');
    if (noMoreText) noMoreText.classList.add('hidden');
    if (btnLoadMore) btnLoadMore.classList.remove('hidden');

    statusText.textContent = `Indexing Real Businesses for ${niche} in ${city}...`;
    logLine(`Searching Maps database: [${niche}] in [${city}, ${state}]`, '🔍');

    try {
      const res = await fetch('/api/hunt-v2', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ niche, country, state, city, page: 1, limit: 15 })
      });
      const data = await res.json();

      if (data.success && data.leads) {
        allLeads = data.leads;
        speedBadge.textContent = `⚡ Completed in ${data.duration}`;
        statusText.textContent = `Captured ${allLeads.length} genuine businesses in ${city}!`;
        logLine(`Found ${allLeads.length} physical business locations in ${data.duration}.`, '✅');
        renderCards();

        if (loadMoreContainer) {
          loadMoreContainer.classList.remove('hidden');
          if (!data.hasMore) {
            btnLoadMore.classList.add('hidden');
            noMoreText.classList.remove('hidden');
          }
        }
      } else {
        logLine(`Notice: ${data.error || 'No businesses found.'}`, '⚠️');
      }
    } catch (err) {
      logLine('Network error during hunt execution.', '❌');
    } finally {
      btnHunt.disabled = false;
      btnLabel.textContent = '⚡ Launch High-Speed Hunt';
      spinner.classList.add('hidden');
    }
  });
}

// Load More Handler (Pagination)
const btnLoadMore = document.getElementById('btn-load-more');
if (btnLoadMore) {
  btnLoadMore.addEventListener('click', async () => {
    if (!currentSearchParams) return;

    currentPage += 1;
    const loadMoreText = document.getElementById('load-more-text');
    const loadMoreSpinner = document.getElementById('load-more-spinner');
    const noMoreText = document.getElementById('no-more-text');

    btnLoadMore.disabled = true;
    loadMoreText.textContent = 'Loading Next Batch...';
    loadMoreSpinner.classList.remove('hidden');

    try {
      const res = await fetch('/api/hunt-v2', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...currentSearchParams, page: currentPage, limit: 15 })
      });
      const data = await res.json();

      if (data.success && data.leads && data.leads.length > 0) {
        allLeads = [...allLeads, ...data.leads];
        renderCards();

        if (!data.hasMore) {
          btnLoadMore.classList.add('hidden');
          noMoreText.classList.remove('hidden');
        }
      } else {
        btnLoadMore.classList.add('hidden');
        noMoreText.classList.remove('hidden');
      }
    } catch (e) {
      alert('Error fetching more businesses.');
    } finally {
      btnLoadMore.disabled = false;
      loadMoreText.textContent = '📥 Load More Businesses (+15)';
      loadMoreSpinner.classList.add('hidden');
    }
  });
}

// Render Cards (100% Authentic Data Display)
function renderCards() {
  const container = document.getElementById('leads-grid');
  const countBadge = document.getElementById('results-count-badge');
  if (!container) return;

  let filtered = allLeads;
  if (currentFilter === 'has-insta') {
    filtered = allLeads.filter(l => l.instagram);
  } else if (currentFilter === 'has-email') {
    filtered = allLeads.filter(l => l.email);
  } else if (currentFilter === 'has-phone') {
    filtered = allLeads.filter(l => l.phone);
  }

  countBadge.textContent = `${filtered.length} Captured`;
  container.innerHTML = '';

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="col-span-full text-center py-12 text-slate-400 text-xs font-semibold">
        No businesses match this filter. Select "All Verified" to view all records.
      </div>
    `;
    return;
  }

  filtered.forEach((lead, index) => {
    const card = document.createElement('div');
    card.className = 'spatial-card p-6 rounded-3xl flex flex-col justify-between space-y-4 card-appear';
    card.style.animationDelay = `${(index % 15) * 40}ms`;

    const cleanPhone = (lead.phone || '').replace(/[^0-9]/g, '');
    const whatsAppUrl = cleanPhone.length >= 7 ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(`Hello ${lead.name}, I found your business on Maps and wanted to connect.`)}` : null;

    card.innerHTML = `
      <div>
        <div class="flex items-start justify-between gap-2 mb-2">
          <span class="px-2.5 py-1 text-[10px] font-black uppercase tracking-wider bg-blue-50 text-blue-700 rounded-lg border border-blue-200">
            ${lead.niche}
          </span>
          <span class="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
            Place #${lead.id}
          </span>
        </div>

        <h3 class="font-black text-slate-900 text-base leading-snug tracking-tight">
          ${lead.name}
        </h3>

        <p class="text-xs text-slate-500 mt-2 flex items-start leading-relaxed">
          <span class="mr-1.5 text-blue-600 mt-0.5">📍</span>
          <span><strong>Physical Address:</strong> ${lead.fullAddress}</span>
        </p>

        <!-- Google Maps Pin Link -->
        <div class="mt-2.5">
          <a href="${lead.googleMapsUrl}" target="_blank" class="inline-flex items-center space-x-1 text-[11px] font-bold text-blue-600 hover:text-blue-800 bg-blue-50/80 px-2.5 py-1 rounded-lg border border-blue-200/80 transition">
            <span>🗺️ Google Maps Pin (${parseFloat(lead.coordinates.lat).toFixed(4)}, ${parseFloat(lead.coordinates.lon).toFixed(4)})</span>
            <span>↗</span>
          </a>
        </div>
      </div>

      <!-- Scraped Contact Matrix (Raw Authentic Info) -->
      <div class="space-y-2 pt-2 border-t border-slate-100 text-xs">
        <!-- Phone -->
        <div class="flex items-center justify-between py-1 bg-slate-50 px-3 rounded-xl border border-slate-100">
          <span class="text-slate-400 font-bold">📞 Phone:</span>
          ${lead.phone ? `
            <a href="tel:${lead.phone}" class="font-black text-slate-800 hover:text-blue-600 transition">${lead.phone}</a>
          ` : `
            <span class="text-slate-400 font-medium">Not Listed on Maps</span>
          `}
        </div>

        <!-- Website -->
        <div class="flex items-center justify-between py-1 bg-slate-50 px-3 rounded-xl border border-slate-100">
          <span class="text-slate-400 font-bold">🌐 Website:</span>
          ${lead.website ? `
            <a href="${lead.website}" target="_blank" class="font-bold text-blue-600 hover:underline truncate max-w-[170px]">${lead.website.replace('https://', '').replace('http://', '')}</a>
          ` : `
            <span class="text-slate-400 font-medium">No Website Listed</span>
          `}
        </div>

        <!-- Email -->
        <div class="flex items-center justify-between py-1 bg-slate-50 px-3 rounded-xl border border-slate-100">
          <span class="text-slate-400 font-bold">✉️ Email:</span>
          ${lead.email ? `
            <span class="font-mono-code text-[11px] font-bold text-slate-800 truncate max-w-[170px]">${lead.email}</span>
          ` : `
            <span class="text-slate-400 font-medium">Not Listed</span>
          `}
        </div>

        <!-- Instagram -->
        <div class="flex items-center justify-between py-1 bg-slate-50 px-3 rounded-xl border border-slate-100">
          <span class="text-slate-400 font-bold">📸 Instagram:</span>
          ${lead.instagram ? `
            <span class="font-black text-pink-600">${lead.instagram}</span>
          ` : `
            <span class="text-slate-400 font-medium">Not Linked</span>
          `}
        </div>
      </div>

      <!-- Action Buttons -->
      <div class="pt-2 grid grid-cols-2 gap-2">
        ${whatsAppUrl ? `
          <a href="${whatsAppUrl}" target="_blank" class="py-2 text-[11px] font-black bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl transition text-center shadow-sm flex items-center justify-center space-x-1">
            <span>💬 WhatsApp</span>
          </a>
        ` : `
          <button ${lead.phone ? `onclick="navigator.clipboard.writeText('${lead.phone}').then(() => alert('Phone copied!'))"` : 'disabled'} class="py-2 text-[11px] font-bold ${lead.phone ? 'bg-slate-100 hover:bg-slate-200 text-slate-700' : 'bg-slate-100/50 text-slate-400 cursor-not-allowed'} rounded-xl transition text-center">
            ${lead.phone ? 'Copy Phone' : 'No Phone'}
          </button>
        `}
        
        ${lead.email ? `
          <a href="mailto:${lead.email}?subject=Inquiry%20for%20${encodeURIComponent(lead.name)}" class="py-2 text-[11px] font-black bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition text-center shadow-sm flex items-center justify-center space-x-1">
            <span>✉️ Pitch Email</span>
          </a>
        ` : `
          <button ${lead.website ? `onclick="window.open('${lead.website}', '_blank')"` : 'disabled'} class="py-2 text-[11px] font-bold ${lead.website ? 'bg-blue-50 text-blue-600 hover:bg-blue-100' : 'bg-slate-100/50 text-slate-400 cursor-not-allowed'} rounded-xl transition text-center">
            ${lead.website ? 'Visit Website' : 'No Website'}
          </button>
        `}
      </div>
    `;

    container.appendChild(card);
  });
}

// Copy All Emails
const btnCopyEmails = document.getElementById('btn-copy-all-emails');
if (btnCopyEmails) {
  btnCopyEmails.addEventListener('click', () => {
    const emails = allLeads.map(l => l.email).filter(Boolean).join(', ');
    if (!emails) {
      alert('No email addresses available in the current batch.');
      return;
    }
    navigator.clipboard.writeText(emails).then(() => {
      const orig = btnCopyEmails.innerHTML;
      btnCopyEmails.innerHTML = '<span>✅ Copied Emails!</span>';
      setTimeout(() => btnCopyEmails.innerHTML = orig, 2000);
    });
  });
}

// Export CSV
const btnCsv = document.getElementById('btn-download-csv');
if (btnCsv) {
  btnCsv.addEventListener('click', () => {
    if (allLeads.length === 0) {
      alert('Please run a hunt first before exporting.');
      return;
    }
    window.location.href = '/api/export-csv';
  });
}
